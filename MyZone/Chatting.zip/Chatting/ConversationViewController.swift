//
//  ConversationViewController.swift
//  ChatQuickstart
//
//  Created by Nilesh Fasate on 04/05/17.
//  Copyright © 2017 Twilio, Inc. All rights reserved.
//

import UIKit
import TwilioChatClient
import MessageKit
import MapKit
import Pulley
class ConversationViewController: MessagesViewController,UIGestureRecognizerDelegate
{
    //MARK: IBOUTLETs
    @IBOutlet var TapToStartChattingView: UIView!
    
    // MARK: Chat variables
    /// Current chat channel
    var currentChatChannel: TCHChannel? = nil
    /// Array storing the messages
    var tcMessages: [TCHMessage] = []
    /// Array storing typed messages of user
    var typingUsers: [TCHMember] = []
    /// Alert action object
    weak var actionToEnable : UIAlertAction?
    
    /// Index variable
    var userConsumedIndex = 0
    /// Variable storing screen brightness
    var screenBrightNess : CGFloat = 0.0
    /// Variable storing the last sent message
    var lastSendedMessage = ""
    /// Current logged in user
    var currentUser = Sender(id: "123456", displayName: "Dan Leonard")
    /// message sender
    var messageSender: Sender {
        return currentUser
    }
    /// array storing list of messages
    var messageList: [MockMessage] = [] {
        didSet {
            DispatchQueue.main.async {
                self.messagesCollectionView.reloadData()
            }
        }
    }
    /// pulley view controller's object
    public var pulleyVCObj : PulleyViewController!
    
    //MARK:- VIEW DELEGATES
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /// Adjust screen brightness
        adjustScreenBrightness()
        /// Setup UI
        setupUI()
        /// Initialise twilio chat
        initializedTwilioProgrammableChat()
        /// setup tap gestures
        setupTapGesture()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool)
    {
        super.viewDidAppear(animated)
        self.becomeFirstResponder()
        /// Setup delegates of pulley
        setPulleyDelegate()
        /// Method to customise UI and show it to the user
        hideMessageInputAndShowTapView()
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
        if(UIScreen.main.brightness < 0.26)
        {
            UIScreen.main.brightness = screenBrightNess
        }
    }
    
    override var prefersStatusBarHidden : Bool {
        return true
    }
    
    //MARK:- Custom Function
    
    /**
     To adjust the screen brightness.
     */
    func adjustScreenBrightness() {
        
        screenBrightNess = UIScreen.main.brightness
        if(screenBrightNess > 0.25)
        {
            UIScreen.main.brightness = 0.25
        }
    }
    
    /**
     To set UI on view load.
     */
    func setupUI()
    {
        currentUser = Sender(id: identity, displayName: identity)
        messagesCollectionView.messagesDataSource = self
        messagesCollectionView.messagesLayoutDelegate = self
        messagesCollectionView.messagesDisplayDelegate = self
        messagesCollectionView.messageCellDelegate = self
        messagesCollectionView.backgroundColor = UIColor.black
        messageInputBar.delegate = self
        messageInputBar.sendButton.tintColor = UIColor(red: 69/255, green: 193/255, blue: 89/255, alpha: 1)
        scrollsToBottomOnFirstLayout = true //default false
        scrollsToBottomOnKeybordBeginsEditing = true // default false
        
        if #available(iOS 11.0, *) {
            automaticallyAdjustsScrollViewInsets = false
        }else {
            self.automaticallyAdjustsScrollViewInsets = true
        }
        
        //Setting pulley View Controllers
        if pulleyVCObj != nil
        {
            pulleyVCObj.delegate = self
        }
    }
    
    /**
     Initialized Twilio programmable chat on controller load.
     */
    func initializedTwilioProgrammableChat() {
        TwiliochatSingleton.shared.twilioChatDelegate = self
        if TwiliochatSingleton.shared.generalChannel != nil
        {
            self.currentChatChannel = TwiliochatSingleton.shared.generalChannel
            self.tcMessages = TwiliochatSingleton.shared.tcMessages
            
            for message in tcMessages
            {
                let finalMessageStr = message.body?.trimmingCharacters(in: .whitespacesAndNewlines)
                let sender = Sender(id: message.author!, displayName: message.author!)
                messageList.append(MockMessage(text: finalMessageStr!, sender: sender, messageId: UUID().uuidString, date: message.timestampAsDate!))
                
                print("Message body: \(String(describing: message.body))")
            }
            
            print("MessageList \(messageList)")
            
            self.title = NSLocalizedString((currentChatChannel?.friendlyName)!, comment: "")
            self.messagesCollectionView.reloadData()
            DispatchQueue.main.async {
                if self.tcMessages.count > 0 {
                    self.messagesCollectionView.scrollToBottom()
                }
            }
        }else
        {
            TwiliochatSingleton.shared.connectClientWithCompletion(completion: { (succeeded, error) in
                if succeeded {
                    
                }else {
                    self.logMessage(messageText: NSLocalizedString(error.debugDescription, comment: ""))
                }
            })
        }
    }
    
    /**
     Set Pulley Delegate
     */
    func setPulleyDelegate()
    {
        if pulleyVCObj != nil
        {
            pulleyVCObj.setDrawerPosition(position: .collapsed, animated: false)
        }
    }
    
    /**
     Method to show Input view
     */
    func showMessageInputAndHideTapView()
    {
        messageInputBar.isHidden = false
        TapToStartChattingView.isHidden = true
    }
    
    /**
     Method to hide Input view
     */
    func hideMessageInputAndShowTapView()
    {
        messageInputBar.isHidden = true
        TapToStartChattingView.isHidden = false
        self.view.bringSubview(toFront: self.TapToStartChattingView)
    }
    
    /**
     Display toast message on success or failed.
     - Parameter messageText: The message to display on Toast.
     */
    func logMessage(messageText: String)
    {
        print("Error:- \(messageText)")
        AlertView.showToastAt(UIScreen.main.bounds.size.height - 150, viewHeight: 45.0, viewWidth: self.view.frame.size.width, bgColor: Macros.Colors.yellowColor, shadowColor: UIColor.darkGray, txtColor: UIColor.white, onScreenTime: 2.0, title: messageText, view: nil)
    }
    
    /**
     To retrive first message of the day.
     */
    func firstMessageOfTheDay(_ message:MessageType, previousMessage:MessageType ) -> Bool {
        if messageList.count > 0
        {
            let messageDate = message.sentDate
            let previouseMessageDate = previousMessage.sentDate
            
            let calendar = NSCalendar.current
            let day = calendar.dateComponents([.day], from: messageDate)
            let previouseMessageDay = calendar.dateComponents([.day], from: previouseMessageDate)
            if day == previouseMessageDay {
                return false
            } else {
                return true
            }
        }else {
            return true
        }
    }    
    
    /**
     Get most recent message from Twilio server (limit 100 messages).
     */
    func getMostRecentMessages()
    {
        //Loader.hide()
        tcMessages.removeAll()
        messageList.removeAll()
        TwiliochatSingleton.shared.tcMessages.removeAll()
        if currentChatChannel != nil
        {
            self.title = currentChatChannel?.friendlyName
            currentChatChannel?.messages?.getLastWithCount(100) { (result, messages) in
                if (result.isSuccessful())
                {
                    for message in messages!
                    {
                        let finalMessageStr = message.body?.trimmingCharacters(in: .whitespacesAndNewlines)
                        self.tcMessages.append(message)
                        TwiliochatSingleton.shared.tcMessages.append(message)
                        
                        let sender = Sender(id: message.author!, displayName: message.author!)
                        self.messageList.append(MockMessage(text: finalMessageStr!, sender: sender, messageId: UUID().uuidString, date: message.timestampAsDate!))
                        
                        print("Message body: \(String(describing: message.body))")
                    }
                    
                    print("MessageList \(self.messageList)")
                    
                    self.messagesCollectionView.reloadData()
                    DispatchQueue.main.async {
                        if self.tcMessages.count > 0 {
                            self.messagesCollectionView.scrollToBottom()
                        }
                    }
                }else {
                    
                    AlertView.showToastAt(UIScreen.main.bounds.size.height - 200, viewHeight: 45.0, viewWidth: self.view.frame.size.width, bgColor: Macros.Colors.yellowColor, shadowColor: UIColor.darkGray, txtColor: UIColor.white, onScreenTime: 1.5, title: NSLocalizedString("Old messages not found", comment: ""), view: nil)
                }
            }
        }
    }
    
    /**
     To set read by status for the messages.
     */
    func populateConsumptionHorizonData()
    {
        let lastConsumedMessageIndex = currentChatChannel?.messages?.lastConsumedMessageIndex
        
        if (lastConsumedMessageIndex != nil) && self.tcMessages.last?.index == lastConsumedMessageIndex
        {
            userConsumedIndex = lastConsumedMessageIndex as! Int
        }
    }
    
    /**
     To show typing users name on textfield.
     */
    func reloadTypingUserTextLabel()
    {
        if typingUsers.count > 0
        {
            //typingLabelHeightConstraint.constant = 30
            var membersString = ""
            var nIdx = 0
            
            for member in typingUsers
            {
                if nIdx > 0 && nIdx < typingUsers.count - 1
                {
                    membersString += ", "
                }else if nIdx > 0 && nIdx == typingUsers.count - 1{
                    membersString += " and "
                }
                membersString += member.identity!
                nIdx += 1
            }
            
            //var diviser = " is"
            if typingUsers.count > 1
            {
                //diviser = " are"
            }
        }else {
        }
    }
    
    /**
     Join channel/group with channel unique name.
     */
    func joinChatRoom(with currentChannelName: String) {
        if chattingClient != nil {
            chattingClient?.channelsList()?.channel(withSidOrUniqueName: currentChannelName, completion: { (result, channel) in
                if let currentChannel = channel {
                    self.currentChatChannel = currentChannel
                    TwiliochatSingleton.shared.generalChannel = channel
                    self.self.currentChatChannel?.join(completion: { result in
                        if (result.isSuccessful()) {
                            AlertView.showToastAt(UIScreen.main.bounds.size.height - 200, viewHeight: 45.0, viewWidth: self.view.frame.size.width, bgColor: Macros.Colors.yellowColor, shadowColor: UIColor.darkGray, txtColor: UIColor.white, onScreenTime: 1.5, title: NSLocalizedString("Successfully joined channel.", comment: ""), view: nil)
                            print("Channel joined with result \(String(describing: result))")
                            self.getMostRecentMessages()
                        }else
                        {
                            AlertView.showToastAt(UIScreen.main.bounds.size.height - 200, viewHeight: 45.0, viewWidth: self.view.frame.size.width, bgColor: Macros.Colors.yellowColor, shadowColor: UIColor.darkGray, txtColor: UIColor.white, onScreenTime: 1.5, title: NSLocalizedString("Failed to join channel, please try again.", comment: ""), view: nil)
                        }
                    })
                } else {
                    // Create the general channel (for public use) if it hasn't been created yet
                    self.createChannel(displayName:"First Responder", channelName: currentChannelName)
                }
            })
        }
    }
    
    /**
     Gesture Recognizer
     */
    
    func setupTapGesture()
    {
        let tapGesture = UITapGestureRecognizer(target: self,action: #selector(self.closeKeyBoard))
        self.view.addGestureRecognizer(tapGesture)
        
        let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeDown.delegate = self 
        swipeDown.direction = UISwipeGestureRecognizerDirection.down
        self.view.addGestureRecognizer(swipeDown)
        
    }
    
    /**
     Method to handle the swipe gesture
     */
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer)
    {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizerDirection.down:
                closeKeyBoard()
            default:
                break
            }
        }
    }
    
    /**
     Delegate method to handle the swipe gesture --May be used in future
     */
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        
        //        if let swipeGesture = gestureRecognizer as? UISwipeGestureRecognizer {
        //            switch swipeGesture.direction {
        //            case UISwipeGestureRecognizerDirection.down:
        //                closeKeyBoard()
        //            default:
        //                break
        //            }
        //        }
        return true
    }
    
    /**
     Method to close keyboard
     */
    @objc func closeKeyBoard()
    {
        messageInputBar.inputTextView.resignFirstResponder()
    }
    
    /// To create new channel
    ///
    /// - Parameters:
    ///   - displayName: channel display/friendly name
    ///   - channelName: channel name
    func createChannel(displayName: String, channelName: String)
    {
        if chattingClient != nil {
            chattingClient?.channelsList()?.createChannel(options: [TCHChannelOptionFriendlyName: displayName, TCHChannelOptionType: TCHChannelType.public.rawValue], completion: { (result, channel) -> Void in
                if (result.isSuccessful()) {
                    AlertView.showToastAt(UIScreen.main.bounds.size.height - 200, viewHeight: 45.0, viewWidth: self.view.frame.size.width, bgColor: Macros.Colors.yellowColor, shadowColor: UIColor.darkGray, txtColor: UIColor.white, onScreenTime: 1.5, title: NSLocalizedString("Channel_created_Success", comment: ""), view: nil)
                    
                    self.currentChatChannel = channel
                    TwiliochatSingleton.shared.generalChannel = channel
                    self.currentChatChannel?.join(completion: { result in
                        self.currentChatChannel?.setUniqueName(channelName, completion: { result in
                            print("channel unique name set")
                            self.title = self.currentChatChannel?.friendlyName
                        })
                    })
                }else {
                    AlertView.showToastAt(UIScreen.main.bounds.size.height - 200, viewHeight: 45.0, viewWidth: self.view.frame.size.width, bgColor: Macros.Colors.yellowColor, shadowColor: UIColor.darkGray, txtColor: UIColor.white, onScreenTime: 1.5, title: NSLocalizedString("Fail_To_create_channel", comment: ""), view: nil)
                }
            })
        }
    }
    
    //MARK:- MessageKit Custom Fuction
    /**
     To get avatar image.
     */
    func getAvatarFor(sender: Sender) -> Avatar {
        return Avatar(image: nil, initals: sender.displayName.acronym())
    }
    
    /**
     Get previous message in message list.
     */
    func getPreviousMessage(_ indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> MessageType?
    {
        guard let dataSource = messagesCollectionView.messagesDataSource else { return nil }
        if indexPath.section == 0 { return nil }
        let previousSection = indexPath.section - 1
        let previousIndexPath = IndexPath(item: 0, section: previousSection)
        let previousMessage = dataSource.messageForItem(at: previousIndexPath, in: messagesCollectionView)
        return previousMessage
    }
    
    //MARK:- IBACTION FUNCTIONS
    /**
     Action method
     */
    @IBAction func TapToStartChattingAction(_ sender: UIButton) {
        if pulleyVCObj != nil
        {
            UIView.animate(withDuration: 1.0, animations: {
                self.TapToStartChattingView.isHidden = true
            }, completion: { (true) in
                self.pulleyVCObj.setDrawerPosition(position: .open)
                self.messageInputBar.isHidden = false
            })
        }
    }
}

// MARK:- Twilio Chat Delegate
extension ConversationViewController: TwilioChatCustomDelegate
{
    /** Called when the client synchronization state changes during startup.
     
     @param client The chat client.
     @param status The current synchronization status of the client.
     */
    func chatClient(_ client: TwilioChatClient!, synchronizationStatusUpdated status: TCHClientSynchronizationStatus) {
        print("client123 - \(String(describing: client?.connectionState.rawValue))")
        print("status123 - \(status.rawValue)")
        if status == .completed {
            let currentChannelName = "Channel-\(MPUserDefaults.sharedInstance.getUserId())"
            joinChatRoom(with: currentChannelName)
        }else if status == .failed
        {
            AlertView.showToastAt(UIScreen.main.bounds.size.height - 200, viewHeight: 45.0, viewWidth: self.view.frame.size.width, bgColor: Macros.Colors.yellowColor, shadowColor: UIColor.darkGray, txtColor: UIColor.white, onScreenTime: 1.5, title: NSLocalizedString("Fail_To_create_channel", comment: ""), view: nil)
        }
    }
    
    // Handle channel events
    /** Called when the current user has a channel added to their channel list.
     
     @param client The chat client.
     @param channel The channel.
     */
    func chatClient(_ client: TwilioChatClient!, channelAdded channel: TCHChannel!) {
        if(channel.status == TCHChannelStatus.invited) {
            
        }
    }
    
    /** Called when one of the current users channels is changed.
     */
    func chatClient(_ client: TwilioChatClient!, channelChanged channel: TCHChannel!) {
        
    }
    
    /** Called when one of the current users channels is deleted.
     */
    func chatClient(_ client: TwilioChatClient!, channelDeleted channel: TCHChannel!) {
        
    }
    
    // Handle member events
    /** Called when a channel the current user is subscribed to has a new member join.
     
     @param client The chat client.
     @param channel The channel.
     @param member The member.
     */
    func chatClient(_ client: TwilioChatClient!, channel: TCHChannel!, memberJoined member: TCHMember!) {
        
        AlertView.showToastAt(UIScreen.main.bounds.size.height - 200, viewHeight: 45.0, viewWidth: self.view.frame.size.width, bgColor: Macros.Colors.yellowColor, shadowColor: UIColor.darkGray, txtColor: UIColor.white, onScreenTime: 1.5, title: "\(member.identity!) \(NSLocalizedString("joined the channel", comment: ""))", view: nil)
    }
    
    /** Called when a channel the current user is subscribed to has a member modified.
     */
    func chatClient(_ client: TwilioChatClient!, channel: TCHChannel!, memberChanged member: TCHMember!) {
        
    }
    
    /** Called when a channel the current user is subscribed to has a member leave.
     */
    func chatClient(_ client: TwilioChatClient!, channel: TCHChannel!, memberLeft member: TCHMember!) {
        AlertView.showToastAt(UIScreen.main.bounds.size.height - 200, viewHeight: 45.0, viewWidth: self.view.frame.size.width, bgColor: Macros.Colors.yellowColor, shadowColor: UIColor.darkGray, txtColor: UIColor.white, onScreenTime: 1.5, title: "\(member.identity!) \(NSLocalizedString("leave the channel", comment: ""))", view: nil)
    }
    
    /** Called when a member of a channel starts typing.
     */
    func chatClient(_ client: TwilioChatClient!, typingStartedOn channel: TCHChannel!, member: TCHMember!) {
        typingUsers.append(member)
        reloadTypingUserTextLabel()
    }
    
    /** Called when a member of a channel ends typing.
     */
    func chatClient(_ client: TwilioChatClient!, typingEndedOn channel: TCHChannel!, member: TCHMember!) {
        if let idX = typingUsers.index(of: member)
        {
            typingUsers.remove(at: idX)
            reloadTypingUserTextLabel()
        }
    }
    
    /// Handle message events
    /** Called when a channel the current user is subscribed to receives a new message.
     
     @param client The chat client.
     @param channel The channel.
     @param message The message.
     */
    func chatClient(_ client: TwilioChatClient!, channel: TCHChannel!, messageAdded message: TCHMessage!) {
        self.tcMessages.append(message)
        TwiliochatSingleton.shared.tcMessages.append(message)
        
        //if lastSendedMessage != message?.body, messageList.last?.sentDate.addingTimeInterval(1.0) != message?.timestampAsDate
        if message?.author != currentSender().displayName
        {
            let sender = Sender(id: message.author!, displayName: message.author!)
            messageList.append(MockMessage(text: message.body!, sender: sender, messageId: UUID().uuidString, date: message.timestampAsDate!))
            self.messagesCollectionView.reloadData()
            DispatchQueue.main.async {
                if self.tcMessages.count > 0 {
                    self.messagesCollectionView.scrollToBottom()
                }
            }
        }
    }
    
    /** Called when a message on a channel the current user is subscribed to is modified.
     */
    func chatClient(_ client: TwilioChatClient!, channel: TCHChannel!, messageChanged message: TCHMessage!) {
        
    }
    
    /** Called when a message on a channel the current user is subscribed to is deleted.
     */
    func chatClient(_ client: TwilioChatClient!, channel: TCHChannel!, messageDeleted message: TCHMessage!) {
        
    }
    
    /** Called when an error occurs.
     
     @param client The chat client.
     @param error The error.
     */
    func chatClient(_ client: TwilioChatClient!, errorReceived error: TCHError!) {
        print("Error - \(error.debugDescription)")
        //Loader.hide()
        
        AlertView.showToastAt(UIScreen.main.bounds.size.height - 200, viewHeight: 45.0, viewWidth: self.view.frame.size.width, bgColor: Macros.Colors.yellowColor, shadowColor: UIColor.darkGray, txtColor: UIColor.white, onScreenTime: 1.5, title: "Error - \(error.debugDescription)", view: nil)
    }
}

//MARK:- MessageKit Functions and Delegate
extension ConversationViewController: MessagesDataSource {
    
    
    /// method return the current sender
    ///
    /// - Returns: sender object
    func currentSender() -> Sender {
        return messageSender
    }
    
    /// method returns the number of messages
    ///
    /// - Parameter messagesCollectionView: message collection view
    /// - Returns: returns the count of messages
    func numberOfMessages(in messagesCollectionView: MessagesCollectionView) -> Int {
        return messageList.count
    }
    
    /// method returns the text message
    ///
    /// - Parameters:
    ///   - indexPath: indexpath of the message
    ///   - messagesCollectionView: message collection view
    /// - Returns: returns the message type
    func messageForItem(at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> MessageType {
        return messageList[indexPath.section]
    }
    
    /// method returns the avatar/ profile image of the user
    ///
    /// - Parameters:
    ///   - message: message
    ///   - indexPath: indexpath of the message
    ///   - messagesCollectionView: collection view controller
    /// - Returns: Avatar
    func avatar(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> Avatar {
        
        if messageList.count > 0
        {
            return getAvatarFor(sender: message.sender)
        }else {
            return Avatar()
        }
    }
    
    func cellTopLabelAttributedText(for message: MessageType, at indexPath: IndexPath) -> NSAttributedString? {
        // Sent by current user, skip
        if isFromCurrentSender(message: message) {
            return nil
        }
        // Same as previous sender, skip
        if let previousMessage = getPreviousMessage(indexPath, in: messagesCollectionView)
        {
            if previousMessage.sender.displayName == message.sender.displayName {
                return nil
            }
        }
        
        var attributes = [NSAttributedStringKey: AnyObject]()
        attributes[NSAttributedStringKey.foregroundColor] = UIColor.white
        attributes[NSAttributedStringKey.font] = UIFont.preferredFont(forTextStyle: .caption1)
        return NSAttributedString(string: message.sender.displayName, attributes: attributes)
    }
    
    func cellBottomLabelAttributedText(for message: MessageType, at indexPath: IndexPath) -> NSAttributedString? {
        if messageList.count > 0
        {
            let messageDate = message.sentDate
            let time = Singleton.sharedInstance.convertDateTimeToTime(date: messageDate)
            
            //            //check if outgoing
            //            if message.sender.displayName != currentSender().displayName
            //            {
            //                //Sent, Deliver, Read
            //                let combinedData = time + " " + currentMessage.senderDisplayName
            //                return NSAttributedString(string:combinedData)
            //            }
            
            var attributes = [NSAttributedStringKey: AnyObject]()
            attributes[NSAttributedStringKey.foregroundColor] = UIColor.white
            attributes[NSAttributedStringKey.font] = UIFont.preferredFont(forTextStyle: .caption1)
            return NSAttributedString(string: time, attributes: attributes)
        }
        return nil
    }
}

// MARK: - MessagesDisplayDelegate
extension ConversationViewController: MessagesDisplayDelegate {
    
    func backgroundColor(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> UIColor {
        return isFromCurrentSender(message: message) ? UIColor.lightGray : UIColor(red: 230/255, green: 230/255, blue: 230/255, alpha: 1)
    }
    
    func textColor(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> UIColor {
        return isFromCurrentSender(message: message) ? .white : .darkText
    }
    
    func messageStyle(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> MessageStyle {
        
        // Same as previous sender, skip
        if let previousMessage = getPreviousMessage(indexPath, in: messagesCollectionView)
        {
            if previousMessage.sender.displayName == message.sender.displayName {
                return .bubble
            }
        }
        
        let corner: MessageStyle.TailCorner = isFromCurrentSender(message: message) ? .topRight : .topLeft
        return .bubbleTail(corner, .pointedEdge)
        //        let configurationClosure = { (view: MessageContainerView) in}
        //        return .custom(configurationClosure)
    }
    
    func messageHeaderView(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> MessageHeaderView {
        let header = messagesCollectionView.dequeueReusableHeaderView(MessageDateHeaderView.self, for: indexPath)
        header.dateLabel.text = ""
        
        if let previousMessage = getPreviousMessage(indexPath, in: messagesCollectionView), messageList.count > 0
        {
            if firstMessageOfTheDay(message, previousMessage: previousMessage)
            {
                header.dateLabel.font = .boldSystemFont(ofSize: 15)
                header.dateLabel.text = Singleton.sharedInstance.convertDateTimeToDate(date: message.sentDate)
            }
        }
        return header
    }
    
    func shouldDisplayHeader(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> Bool {
        
        if let previousMessage = getPreviousMessage(indexPath, in: messagesCollectionView), messageList.count > 0
        {
            if firstMessageOfTheDay(message, previousMessage: previousMessage)
            {
                return true
            }
        }
        return false
    }
}

// MARK: - MessagesLayoutDelegate

extension ConversationViewController: MessagesLayoutDelegate {
    
    func messageLabelInset(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> UIEdgeInsets {
        guard let dataSource = messagesCollectionView.messagesDataSource else { return .zero }
        
        if dataSource.isFromCurrentSender(message: message) {
            if let currentMessage = tcMessages[indexPath.section].body, currentMessage.length <= 2 {
                return UIEdgeInsets(top: 7, left: 22, bottom: 7, right: 5)
            }
            return UIEdgeInsets(top: 7, left: 18, bottom: 7, right: 10)
        } else {
            if let currentMessage = tcMessages[indexPath.section].body, currentMessage.length <= 2 {
                return UIEdgeInsets(top: 7, left: 5, bottom: 7, right: 22)
            }
            return UIEdgeInsets(top: 7, left: 10, bottom: 7, right: 18)
        }
    }
    
    func messagePadding(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> UIEdgeInsets {
        if isFromCurrentSender(message: message) {
            return UIEdgeInsets(top: 0, left: 30, bottom: 0, right: 4)
        } else {
            // Same as previous sender, skip
            if let previousMessage = getPreviousMessage(indexPath, in: messagesCollectionView)
            {
                if previousMessage.sender.displayName == message.sender.displayName {
                    return UIEdgeInsets(top: 0, left: 38, bottom: 0, right: 30)
                }
            }
            return UIEdgeInsets(top: 0, left: 4, bottom: 0, right: 30)
        }
    }
    
    func cellTopLabelAlignment(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> LabelAlignment {
        if isFromCurrentSender(message: message) {
            return .messageTrailing(UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0))
        } else {
            return .messageLeading(UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0))
        }
    }
    
    func cellBottomLabelAlignment(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> LabelAlignment {
        if isFromCurrentSender(message: message) {
            return .messageLeading(UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0))
        } else {
            return .messageTrailing(UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0))
        }
    }
    
    func avatarAlignment(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> AvatarAlignment {
        return .messageTop
    }
    
    func avatarSize(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> CGSize {
        // Sent by current user, skip
        if message.sender.displayName == currentSender().displayName {
            return .zero
        }
        
        // Same as previous sender, skip
        if let previousMessage = getPreviousMessage(indexPath, in: messagesCollectionView)
        {
            if previousMessage.sender.displayName == message.sender.displayName {
                return .zero
            }
        }
        
        return CGSize(width: 30, height: 30)
        //return .zero
    }
    
    func footerViewSize(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> CGSize {
        // Same as previous sender, skip
        if let previousMessage = getPreviousMessage(indexPath, in: messagesCollectionView)
        {
            if previousMessage.sender.displayName == message.sender.displayName {
                return .zero
            }
        }
        return CGSize(width: messagesCollectionView.bounds.width, height: 10)
    }
    
}

// MARK: - LocationMessageLayoutDelegate

extension ConversationViewController: LocationMessageLayoutDelegate {
    
    func heightForLocation(message: MessageType, at indexPath: IndexPath, with maxWidth: CGFloat, in messagesCollectionView: MessagesCollectionView) -> CGFloat {
        return 200
    }
    
}

// MARK: - MediaMessageLayoutDelegate

extension ConversationViewController: MediaMessageLayoutDelegate {}

// MARK: - MessageCellDelegate

extension ConversationViewController: MessageCellDelegate {
    
    func didTapAvatar<T>(in cell: MessageCollectionViewCell<T>) {
        print("Avatar tapped")
    }
    
    func didTapMessage<T>(in cell: MessageCollectionViewCell<T>) {
        print("Message tapped")
    }
    
    func didTapTopLabel<T>(in cell: MessageCollectionViewCell<T>) {
        print("Top label tapped")
    }
    
    func didTapBottomLabel<T>(in cell: MessageCollectionViewCell<T>) {
        print("Bottom label tapped")
    }
    
}

// MARK: - MessageLabelDelegate

extension ConversationViewController: MessageLabelDelegate {
    
    func didSelectAddress(_ addressComponents: [String : String]) {
        print("Address Selected: \(addressComponents)")
    }
    
    func didSelectDate(_ date: Date) {
        print("Date Selected: \(date)")
    }
    
    func didSelectPhoneNumber(_ phoneNumber: String) {
        print("Phone Number Selected: \(phoneNumber)")
    }
    
    func didSelectURL(_ url: URL) {
        print("URL Selected: \(url)")
    }
    
}

// MARK: - LocationMessageDisplayDelegate

extension ConversationViewController: LocationMessageDisplayDelegate {
    
    func annotationViewForLocation(message: MessageType, at indexPath: IndexPath, in messageCollectionView: MessagesCollectionView) -> MKAnnotationView? {
        let annotationView = MKAnnotationView(annotation: nil, reuseIdentifier: nil)
        let pinImage = #imageLiteral(resourceName: "pin")
        annotationView.image = pinImage
        annotationView.centerOffset = CGPoint(x: 0, y: -pinImage.size.height / 2)
        return annotationView
    }
    
    func animationBlockForLocation(message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> ((UIImageView) -> Void)? {
        return { view in
            view.layer.transform = CATransform3DMakeScale(0, 0, 0)
            view.alpha = 0.0
            UIView.animate(withDuration: 0.6, delay: 0, usingSpringWithDamping: 0.9, initialSpringVelocity: 0, options: [], animations: {
                view.layer.transform = CATransform3DIdentity
                view.alpha = 1.0
            }, completion: nil)
        }
    }
}

// MARK: - MessageInputBarDelegate

extension ConversationViewController: MessageInputBarDelegate {
    
    func messageInputBar(_ inputBar: MessageInputBar, didPressSendButtonWith text: String) {
        
        let message = text.trimmingCharacters(in: .whitespacesAndNewlines)
        
        lastSendedMessage = message
        messageList.append(MockMessage(text: message, sender: currentSender(), messageId: UUID().uuidString, date: Date()))
        inputBar.inputTextView.text = String()
        messagesCollectionView.reloadData()
        messagesCollectionView.scrollToBottom()
        
        if message != ""
        {
            // Where "channel" is a TCHChannel
            if let messages = self.currentChatChannel?.messages {
                let options = TCHMessageOptions().withBody(message)
                messages.sendMessage(with: options) { result, message in
                    if result.isSuccessful() {
                        print("Message sent.")
                    } else {
                        print("Message NOT sent.")
                    }
                }
            }
        }
    }
    
    func messageInputBar(_ inputBar: MessageInputBar, textViewTextDidChangeTo text: String) {
        
    }
}

//MARK:- ------ PulleyDrawerViewControllerDelegate DELEGATES ------
extension ConversationViewController : PulleyDrawerViewControllerDelegate
{
    func collapsedDrawerHeight(bottomSafeArea: CGFloat) -> CGFloat
    {
        return CGFloat(50)
    }
    
    func partialRevealDrawerHeight(bottomSafeArea: CGFloat) -> CGFloat
    {
        return self.view.bounds.height/2
    }
    
    func supportedDrawerPositions() -> [PulleyPosition]
    {
        return PulleyPosition.all
    }
}

//MARK:- ------ PULLEY DELEGATES ------
extension ConversationViewController : PulleyDelegate
{
    func drawerPositionDidChange(drawer: PulleyViewController, bottomSafeArea: CGFloat) {
        if drawer.drawerPosition == .collapsed {
            closeKeyBoard()
            hideMessageInputAndShowTapView()
        }else if drawer.drawerPosition == .partiallyRevealed || drawer.drawerPosition == .open
        {
            showMessageInputAndHideTapView()
        }
    }
}

//Did Receive remote
//if let chatClient1 = chattingClient, chattingClient?.user != nil
//{
//    // If your reference to the Chat client exists and is initialized, send the notification to it
//
//    chatClient1.handleNotification(userInfo, completion: { (result) in
//    })
//
//    if(UIApplication.shared.applicationState == .background || UIApplication.shared.applicationState == .inactive)
//    {
//        if let topController = window?.visibleViewController(), topController.isKind(of: ConversationViewController.self)
//        {
//            let vc = StoryboardManager.sharedInstance.trackingStoryboard().instantiateViewController(withIdentifier: "MessagesViewController")
//            Singleton.sharedInstance.topMostController().navigationController?.pushViewController(vc, animated: true)
//        }
//    }
//
//    if let aps = userInfo["aps"] as? Dictionary<String, AnyObject>
//    {
//        if let alertMsg = aps["alert"] as? String
//        {
//            let fullNameArr = alertMsg.characters.split{$0 == ";"}.map(String.init)
//            let channelName = fullNameArr[0]
//            if channelName != ""
//            {
//                globalChannelName = channelName
//            }else {
//                let channelSID = userInfo["channel_sid"] as? String
//                globalChannelName = channelSID!
//            }
//
//            // delegate?.joinChannel()
//        }
//    }
//} else
//{
//    // Store the notification for later handling
//    receivedNotification = userInfo
//}

