//
//  TwiliochatSingleton.swift
//  HeroEyez
//
//  Created by Temp on 13/09/17.
//  Copyright © 2017 Delaplex Softwares. All rights reserved.
//

import UIKit
import TwilioChatClient
import TwilioAccessManager

protocol TwilioChatCustomDelegate {
    
    func chatClient(_ client: TwilioChatClient!, synchronizationStatusUpdated status: TCHClientSynchronizationStatus)
    func chatClient(_ client: TwilioChatClient!, channelAdded channel: TCHChannel!)
    func chatClient(_ client: TwilioChatClient!, channelChanged channel: TCHChannel!)
    func chatClient(_ client: TwilioChatClient!, channelDeleted channel: TCHChannel!)
    func chatClient(_ client: TwilioChatClient!, channel: TCHChannel!, memberJoined member: TCHMember!)
    func chatClient(_ client: TwilioChatClient!, channel: TCHChannel!, memberChanged member: TCHMember!)
    func chatClient(_ client: TwilioChatClient!, channel: TCHChannel!, memberLeft member: TCHMember!)
    func chatClient(_ client: TwilioChatClient!, typingStartedOn channel: TCHChannel!, member: TCHMember!)
    func chatClient(_ client: TwilioChatClient!, typingEndedOn channel: TCHChannel!, member: TCHMember!)
    func chatClient(_ client: TwilioChatClient!, channel: TCHChannel!, messageAdded message: TCHMessage!)
    func chatClient(_ client: TwilioChatClient!, channel: TCHChannel!, messageChanged message: TCHMessage!)
    func chatClient(_ client: TwilioChatClient!, channel: TCHChannel!, messageDeleted message: TCHMessage!)
    func chatClient(_ client: TwilioChatClient!, errorReceived error: TCHError!)
}

class TwiliochatSingleton: NSObject
{
    static let shared = TwiliochatSingleton()
    var generalChannel: TCHChannel? = nil
    var tcMessages: [TCHMessage] = []
    var twilioChatDelegate : TwilioChatCustomDelegate?
    var accessManager : TwilioAccessManager!
    
    //MARK:- Custom Functions.
    func connectClientWithCompletion(completion: @escaping (Bool, NSError?) -> Void) {
        
        requestTokenWithCompletion { succeeded, token in
            if let token = token, succeeded {
                self.initializeClientWithToken(token)
                completion(succeeded, nil)
            }
            else {
                let error = self.errorWithDescription(description: "Could not get access token", code:301)
                completion(succeeded, error)
            }
        }
    }
    
    func initializeClientWithToken(_ token: String) {
        accessManager = TwilioAccessManager(token:token, delegate:self)
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        TwilioChatClient.chatClient(withToken: token, properties: nil, delegate: self) { result, chatClient in
            guard (result.isSuccessful()) else { return }
            UIApplication.shared.isNetworkActivityIndicatorVisible = true
           chattingClient = chatClient
        }
    }
    
    func updateChatClient() {
        if chattingClient != nil, (chattingClient?.synchronizationStatus == TCHClientSynchronizationStatus.channelsListCompleted || chattingClient?.synchronizationStatus == TCHClientSynchronizationStatus.completed) {
            if let lastToken = updatedPushToken {
                chattingClient?.register(withNotificationToken: lastToken, completion: {(_ result: TCHResult) -> Void in
                    if result.isSuccessful() {
                        
                    }
                    else {
                        // try again?
                    }
                })
            }
            if let lastNotification = receivedNotification {
                
                chattingClient?.handleNotification(lastNotification, completion: { (result) in
                    if result.isSuccessful() {
                        receivedNotification = nil
                    }
                    else {
                        // try again?
                    }
                })
            }
        }
    }

    /**
     Get most recent message from Twilio server (limit 100 messages).
     */
    func getMostRecentMessages()
    {
        //Loader.hide()
        tcMessages.removeAll()
        if generalChannel != nil
        {
            generalChannel?.messages?.getLastWithCount(100) { (result, messages) in
                if (result.isSuccessful())
                {
                    for message in messages!
                    {
                        self.tcMessages.append(message)
                        print("Message body: \(String(describing: message.body))")
                    }
                    
                }else
                {
                }
            }
        }
    }
    
    /// To create new channel
    ///
    /// - Parameters:
    ///   - displayName: channel display/friendly name
    ///   - channelName: channel name
    func createChannel(displayName: String, channelName: String)
    {
        chattingClient?.channelsList()?.createChannel(options: [TCHChannelOptionFriendlyName: displayName, TCHChannelOptionType: TCHChannelType.public.rawValue], completion: { (result, channel) -> Void in
            if (result.isSuccessful()) {
                self.generalChannel = channel
                self.generalChannel?.join(completion: { result in
                    self.generalChannel?.setUniqueName(channelName, completion: { result in
                        print("channel unique name set")
                    })
                })
            }else {
                
            }
        })
    }
    
    /// Join to channel/group
    func joinChatRoom(_ client: TwilioChatClient) {
        
        let currentChannelName = "Channel-\(MPUserDefaults.sharedInstance.getUserId())"
        
        client.channelsList()?.channel(withSidOrUniqueName: currentChannelName, completion: { (result, channel) in
            if result.isSuccessful()
            {
                if let currentChannel = channel {
                    self.generalChannel = currentChannel
                    self.generalChannel?.join(completion: { result in
                        if (result.isSuccessful()) {
                            self.getMostRecentMessages()
                        }else
                        {
                            
                        }
                    })
                } else {
                    // Create the general channel (for public use) if it hasn't been created yet
                    self.createChannel(displayName:"First Responder", channelName: currentChannelName)
                }
            }
        })
    }
    
    func errorWithDescription(description: String, code: Int) -> NSError {
        let userInfo = [NSLocalizedDescriptionKey : description]
        return NSError(domain: "app", code: code, userInfo: userInfo)
    }
    
    //MARK:- WebService call to get Twilio chat Token.
    func requestTokenWithCompletion(completion:@escaping (Bool, String?) -> Void) {
        if let deviceId = UIDevice.current.identifierForVendor?.uuidString {
            let parameters: [String : AnyObject] = [
                "Device"      : deviceId as AnyObject,
                "identity"    : identity as AnyObject,
                ]
            
            Webservices.sharedInstance.postRequest(Macros.ServiceName.getTwilioChatToken, parameters: parameters, showLoader: false) { (response, status, error, time) in
                
                if status == true && error == nil
                {
                    guard let result = (response?.value(forKey: "Status") as? String), result == "Success" else
                    {
                        completion(false, nil)
                        return
                    }
                    
                    let token = response?.value(forKey: "Body") as! String
                    completion(true, token)
                }else
                {
                    completion(false, nil)
                }
            }
        }
    }
}

// MARK:- Twilio Chat Delegate
extension TwiliochatSingleton: TwilioChatClientDelegate, TwilioAccessManagerDelegate
{
    func accessManagerTokenWillExpire(_ accessManager: TwilioAccessManager) {
        // ... obtain new token asynchronously
        requestTokenWithCompletion { succeeded, token in
            if succeeded {
                accessManager.updateToken(token!)
            }else {
                print("Error while trying to get new access token")
            }
        }
    }

    func accessManager(_ accessManager: TwilioAccessManager!, error: Error!) {
        print("Access manager error: \(error.localizedDescription)")
    }
    
    /** Called when the client synchronization state changes during startup.
     
     @param client The chat client.
     @param status The current synchronization status of the client.
     */
    func chatClient(_ client: TwilioChatClient, synchronizationStatusUpdated status: TCHClientSynchronizationStatus) {
        print("client123 - \(String(describing: client.connectionState.rawValue))")
        print("status123 - \(status.rawValue)")
        if status == .completed {
            if let updatedPushToken = updatedPushToken {
                client.register(withNotificationToken: updatedPushToken, completion: { (result) in
                })
            }
            
            if twilioChatDelegate != nil
            {
                twilioChatDelegate?.chatClient(client, synchronizationStatusUpdated: status)
            }else {
                joinChatRoom(client)
            }
        }else if status == .failed
        {
            
        }
    }
    
    //MARK: Handle channel events
    /** Called when the current user has a channel added to their channel list.
     
     @param client The chat client.
     @param channel The channel.
     */
    func chatClient(_ client: TwilioChatClient, channelAdded channel: TCHChannel) {
        if twilioChatDelegate != nil
        {
            twilioChatDelegate?.chatClient(client, channelAdded: channel)
        }
    }
    
    /** Called when one of the current users channels is changed.
     */
    func chatClient(_ client: TwilioChatClient!, channelChanged channel: TCHChannel!) {
        if twilioChatDelegate != nil
        {
            twilioChatDelegate?.chatClient(client, channelChanged: channel)
        }
    }
    
    /** Called when one of the current users channels is deleted.
     */
    func chatClient(_ client: TwilioChatClient, channelDeleted channel: TCHChannel) {
        if twilioChatDelegate != nil
        {
            twilioChatDelegate?.chatClient(client, channelDeleted: channel)
        }
    }
    
    //MARK: Handle member events
    /** Called when a channel the current user is subscribed to has a new member join.
     
     @param client The chat client.
     @param channel The channel.
     @param member The member.
     */
    func chatClient(_ client: TwilioChatClient, channel: TCHChannel, memberJoined member: TCHMember) {
        if twilioChatDelegate != nil
        {
            twilioChatDelegate?.chatClient(client, channel : channel, memberJoined: member)
        }
    }
    
    /** Called when a channel the current user is subscribed to has a member modified.
     */
    func chatClient(_ client: TwilioChatClient!, channel: TCHChannel!, memberChanged member: TCHMember!) {
        if twilioChatDelegate != nil
        {
            twilioChatDelegate?.chatClient(client, channel : channel, memberChanged: member)
        }
    }
    
    /** Called when a channel the current user is subscribed to has a member leave.
     */
    func chatClient(_ client: TwilioChatClient, channel: TCHChannel, memberLeft member: TCHMember) {
        if twilioChatDelegate != nil
        {
            twilioChatDelegate?.chatClient(client, channel : channel, memberLeft: member)
        }
    }
    
    /** Called when a member of a channel starts typing.
     */
    func chatClient(_ client: TwilioChatClient, typingStartedOn channel: TCHChannel, member: TCHMember) {
        if twilioChatDelegate != nil
        {
            twilioChatDelegate?.chatClient(client, typingStartedOn : channel, member: member)
        }
    }
    
    /** Called when a member of a channel ends typing.
     */
    func chatClient(_ client: TwilioChatClient, typingEndedOn channel: TCHChannel, member: TCHMember) {
        if twilioChatDelegate != nil
        {
            twilioChatDelegate?.chatClient(client, typingEndedOn : channel, member: member)
        }
    }
    
    //MARK: Handle message events
    /** Called when a channel the current user is subscribed to receives a new message.
     
     @param client The chat client.
     @param channel The channel.
     @param message The message.
     */
    func chatClient(_ client: TwilioChatClient, channel: TCHChannel, messageAdded message: TCHMessage) {
        if twilioChatDelegate != nil
        {
            twilioChatDelegate?.chatClient(client, channel : channel, messageAdded: message)
        }
        
    }
    
    /** Called when a message on a channel the current user is subscribed to is modified.
     */
    func chatClient(_ client: TwilioChatClient!, channel: TCHChannel!, messageChanged message: TCHMessage!) {
        if twilioChatDelegate != nil
        {
            twilioChatDelegate?.chatClient(client, channel : channel, messageChanged: message)
        }
    }
    
    /**
     Called when a message on a channel the current user is subscribed to is deleted.
     */
    func chatClient(_ client: TwilioChatClient, channel: TCHChannel, messageDeleted message: TCHMessage) {
        if twilioChatDelegate != nil
        {
            twilioChatDelegate?.chatClient(client, channel : channel, messageDeleted: message)
        }
    }
    
    /** Called when an error occurs.
     
     @param client The chat client.
     @param error The error.
     */
    func chatClient(_ client: TwilioChatClient, errorReceived error: TCHError) {
        print("Error - \(error.debugDescription)")
        if twilioChatDelegate != nil
        {
            twilioChatDelegate?.chatClient(client, errorReceived : error)
        }
        
    }
    
}
